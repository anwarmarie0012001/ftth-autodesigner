// Minimal Express backend for FTTH Autodesigner
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { nanoid } = require('nanoid');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Serve static frontend
app.use('/', express.static(path.join(__dirname, 'public')));

// Basic in-memory store (for demo)
const odps = {};

/**
 * Automation endpoint:
 * POST /api/odp/auto
 * body: { count: number, startIndex?: number, splitterType?: "1:4"|"1:8" }
 * returns generated ODPs with mapping info
 */
app.post('/api/odp/auto', (req, res) => {
  const count = parseInt(req.body.count) || 1;
  const startIndex = parseInt(req.body.startIndex) || 1;
  const splitterType = req.body.splitterType || '1:8';
  const created = [];
  for(let i=0;i<count;i++){
    const idx = startIndex + i;
    const id = 'ODP-' + idx.toString().padStart(4,'0');
    const cores = splitterType === '1:4' ? 4 : 8;
    const mapping = [];
    for(let p=0;p<cores;p++){
      mapping.push({
        port: p+1,
        serviceId: 'SVC-' + nanoid(6),
        monitoring: (p % 5 === 0) // simple rule: every 5th is monitoring loop
      });
    }
    const odp = {
      id,
      splitterType,
      cores,
      mapping,
      createdAt: new Date().toISOString()
    };
    odps[id] = odp;
    created.push(odp);
  }
  res.json({ ok: true, created });
});

app.get('/api/odp/:id', (req, res) => {
  const id = req.params.id;
  if(odps[id]){
    res.json({ ok: true, odp: odps[id] });
  } else {
    res.status(404).json({ ok: false, error: 'Not found' });
  }
});

app.get('/api/odps', (req, res) => {
  const list = Object.values(odps);
  res.json({ ok: true, total: list.length, odps: list });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log('FTTH Autodesigner backend running on port', port);
  console.log('Open http://localhost:' + port + ' in your browser');
});

FTTH Autodesigner - Demo package
=================================

Isi:
- server.js        -> Express backend (API + static serving)
- package.json     -> Backend dependencies
- public/          -> Frontend static files (index.html, main.js)
- public/icons     -> SVG icons (odp, splitter, feeder)
- README.md        -> ini berkas

Fitur demo:
- Endpoint POST /api/odp/auto untuk membuat ODP otomatis (massal)
- Endpoint GET /api/odps untuk list ODP
- Frontend example yang memanggil endpoint otomatis tersebut
- Icons SVG untuk ODP, splitter, feeder

Cara jalankan (di mesin lokal Anda):
1. Pastikan Node.js >= 14 terinstall.
2. Di folder project, jalankan:
   npm install
   npm start
3. Buka browser ke http://localhost:3000

Catatan:
- Ini adalah demo minimal untuk menunjukkan frontend-backend yang terkoneksi dan fitur automation ODP.
- Untuk produksi, Anda perlu menambahkan persistensi (database), validasi, autentikasi, testing, CI/CD, dsb.

Selamat — semoga membantu sebagai starting point untuk project FTTH Autodesigner Anda.

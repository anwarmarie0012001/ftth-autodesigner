
from typing import List, Tuple
from shapely.geometry import Point, Polygon
import numpy as np

Coord = Tuple[float, float]  # (lon, lat)

def point_in_polygon(point: Coord, polygon: List[Coord]) -> bool:
    poly = Polygon(polygon)
    return poly.contains(Point(point))

def filter_points_inside(points: List[Coord], polygon: List[Coord]) -> List[Coord]:
    poly = Polygon(polygon)
    return [p for p in points if poly.contains(Point(p))]

def centroid(coords: List[Coord]) -> Coord:
    if not coords:
        raise ValueError("Empty coords for centroid")
    arr = np.asarray(coords, dtype=float)
    c = arr.mean(axis=0)
    return (float(c[0]), float(c[1]))

def batch_by_capacity(points: List[Coord], capacity: int) -> List[List[Coord]]:
    # Simple batching: sort by lon, then lat, then chunk by capacity.
    pts = sorted(points, key=lambda p: (p[0], p[1]))
    return [pts[i:i+capacity] for i in range(0, len(pts), capacity)]

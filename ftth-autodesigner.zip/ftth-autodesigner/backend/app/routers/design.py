
from fastapi import APIRouter
from ..models.ftth import AutoOdpRequest, AutoOdpResponse, OdpFeature, PointCheckRequest, PointCheckResponse
from ..services.geo_utils import point_in_polygon, filter_points_inside, batch_by_capacity, centroid

router = APIRouter()

@router.post("/auto-odp", response_model=AutoOdpResponse)
def auto_odp(req: AutoOdpRequest) -> AutoOdpResponse:
    boundary_poly = req.boundary.polygon
    points = req.buildings.points

    if req.ignore_outside:
        points = filter_points_inside(points, boundary_poly)

    if not points:
        return AutoOdpResponse(odps=[])

    groups = batch_by_capacity(points, req.capacity)
    odps = []
    for g in groups:
        c = centroid(g)
        odps.append(OdpFeature(centroid=c, members=g))
    return AutoOdpResponse(odps=odps)

@router.post("/check", response_model=PointCheckResponse)
def check_point(req: PointCheckRequest) -> PointCheckResponse:
    inside = point_in_polygon(req.point, req.boundary.polygon)
    return PointCheckResponse(inside=inside)

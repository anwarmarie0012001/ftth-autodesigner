
from pydantic import BaseModel, Field
from typing import List, Tuple

Coord = Tuple[float, float]  # (lon, lat)

class Boundary(BaseModel):
    polygon: List[Coord] = Field(..., description="Polygon as list of [lon,lat]")

class BuildingPoints(BaseModel):
    points: List[Coord] = Field(..., description="List of building points [lon,lat]")

class AutoOdpRequest(BaseModel):
    boundary: Boundary
    buildings: BuildingPoints
    capacity: int = Field(16, description="Max buildings per ODP group")
    ignore_outside: bool = Field(True, description="Ignore buildings outside boundary")

class OdpFeature(BaseModel):
    centroid: Coord
    members: List[Coord]

class AutoOdpResponse(BaseModel):
    odps: list[OdpFeature]

class PointCheckRequest(BaseModel):
    boundary: Boundary
    point: Coord

class PointCheckResponse(BaseModel):
    inside: bool

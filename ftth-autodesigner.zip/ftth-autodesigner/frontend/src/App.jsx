
import { useEffect, useMemo, useState } from 'react';
import axios from 'axios';
import { MapContainer, TileLayer, Marker, Polygon, Popup } from 'react-leaflet';
import L from 'leaflet';
import ODCIconImg from '/assets/LogoODC.png';
import ODPIconImg from '/assets/LogoODP.png';

const backend = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';

const iconODC = new L.Icon({
  iconUrl: ODCIconImg,
  iconSize: [28, 28],
  iconAnchor: [14, 28],
  popupAnchor: [0, -28]
});

const iconODP = new L.Icon({
  iconUrl: ODPIconImg,
  iconSize: [24, 24],
  iconAnchor: [12, 24],
  popupAnchor: [0, -24]
});

// Sample boundary & buildings near Jakarta (lon, lat)
const sampleBoundary = [
  [106.80, -6.20],
  [106.84, -6.20],
  [106.84, -6.24],
  [106.80, -6.24],
];

function toLatLng(point) { return [point[1], point[0]]; } // leaflet expects [lat,lon]

export default function App() {
  const [boundary, setBoundary] = useState(sampleBoundary);
  const [buildings, setBuildings] = useState([]);
  const [odps, setOdps] = useState([]);
  const [capacity, setCapacity] = useState(16);
  const [ignoreOutside, setIgnoreOutside] = useState(true);

  // generate random buildings inside bbox once
  useEffect(() => {
    const [minLon, minLat] = [Math.min(...boundary.map(b => b[0])), Math.min(...boundary.map(b => b[1]))];
    const [maxLon, maxLat] = [Math.max(...boundary.map(b => b[0])), Math.max(...boundary.map(b => b[1]))];
    const pts = Array.from({length: 80}).map(() => {
      const lon = minLon + Math.random() * (maxLon - minLon);
      const lat = minLat + Math.random() * (maxLat - minLat);
      return [lon, lat];
    });
    setBuildings(pts);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const center = useMemo(() => {
    const lats = boundary.map(b => b[1]);
    const lons = boundary.map(b => b[0]);
    return [(Math.min(...lats)+Math.max(...lats))/2, (Math.min(...lons)+Math.max(...lons))/2];
  }, [boundary]);

  async function runAuto() {
    try {
      const res = await axios.post(`${backend}/design/auto-odp`, {
        boundary: { polygon: boundary },
        buildings: { points: buildings },
        capacity: Number(capacity),
        ignore_outside: ignoreOutside
      });
      setOdps(res.data.odps || []);
    } catch (e) {
      alert('Failed: ' + (e?.message || 'unknown error'));
    }
  }

  return (
    <div>
      <div className="controls">
        <label>Capacity per ODP:</label>
        <input type="number" value={capacity} min={1} max={64} onChange={e=>setCapacity(e.target.value)} />
        <label>
          <input type="checkbox" checked={ignoreOutside} onChange={e=>setIgnoreOutside(e.target.checked)} />
          Ignore outside boundary
        </label>
        <button onClick={runAuto}>Auto-Place ODP</button>
        <span>Backend: {backend}</span>
      </div>

      <MapContainer id="map" center={[center[0], center[1]]} zoom={14} scrollWheelZoom>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <Polygon positions={boundary.map(toLatLng)} pathOptions={{ weight: 2 }}>
          <Popup>ODC Boundary</Popup>
        </Polygon>

        {/* ODC marker placed at polygon's bbox center for demo */}
        <Marker position={[center[0], center[1]]} icon={iconODC}>
          <Popup>ODC</Popup>
        </Marker>

        {buildings.map((p, i) => (
          <Marker key={'b'+i} position={toLatLng(p)}>
            <Popup>Building #{i+1}<br/>{p[0].toFixed(5)}, {p[1].toFixed(5)}</Popup>
          </Marker>
        ))}

        {odps.map((o, i) => (
          <Marker key={'o'+i} position={toLatLng(o.centroid)} icon={iconODP}>
            <Popup>
              ODP #{i+1}<br/>
              Members: {o.members.length}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}

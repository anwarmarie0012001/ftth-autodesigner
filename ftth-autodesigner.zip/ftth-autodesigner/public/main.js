// Simple frontend that calls the backend automation endpoint
const createBtn = document.getElementById('createBtn');
const resultDiv = document.getElementById('result');
const debug = document.getElementById('debug');

async function createODPs(){
  const count = parseInt(document.getElementById('count').value) || 1;
  const splitter = document.getElementById('splitter').value;
  debug.textContent = 'Mengirim request...';
  try {
    const res = await fetch('/api/odp/auto', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ count, splitterType: splitter })
    });
    const data = await res.json();
    debug.textContent = JSON.stringify(data, null, 2);
    if(data.ok){
      resultDiv.innerHTML = data.created.map(o => {
        return `<div style="padding:8px;border:1px solid #e6eef8;margin:6px;border-radius:8px;">
          <b>${o.id}</b> — splitter ${o.splitterType} — cores ${o.cores}
          <ul>${o.mapping.map(m=>`<li>Port ${m.port}: ${m.serviceId} ${m.monitoring?'<em>(monitoring)</em>':''}</li>`).join('')}</ul>
        </div>`;
      }).join('');
    } else {
      resultDiv.textContent = 'Gagal: ' + (data.error || 'unknown');
    }
  } catch(e){
    debug.textContent = 'Error: ' + e.toString();
  }
}

createBtn.addEventListener('click', createODPs);

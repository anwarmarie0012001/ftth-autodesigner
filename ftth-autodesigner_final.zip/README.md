# FTTH AutoDesigner (Final)

## Jalankan lokal (Docker)
```bash
docker compose up --build
```
Frontend: http://localhost:5173  
Backend: http://localhost:8000

## Jalankan di GitHub Codespaces
- Jalankan backend:
  ```bash
  cd backend
  pip install -r requirements.txt
  uvicorn main:app --host 0.0.0.0 --port 8000
  ```
  Set port 8000 = **Public**.
- Jalankan frontend:
  ```bash
  cd frontend
  npm install
  echo "VITE_BACKEND_URL=https://<workspace-id>-8000.app.github.dev" > .env
  npm run dev
  ```

## Deploy Frontend ke GitHub Pages
- Tambah `VITE_BACKEND_URL` di **Pages > Build and deployment > Environment variables**.
- Build lalu push artefak atau gunakan aksi GitHub Actions standar untuk Vite.

## Deploy Backend ke Render (contoh)
- Buat Web Service dari repo/folder `backend/`.
- Runtime: Docker atau Python + start command:
  ```
  uvicorn main:app --host 0.0.0.0 --port $PORT
  ```
- Atur CORS di `main.py` (sudah terbuka; produksi: batasi domain).

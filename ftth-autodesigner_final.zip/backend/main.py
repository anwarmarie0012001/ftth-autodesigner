from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any, Tuple

app = FastAPI(title="FTTH AutoDesigner Backend", version="1.0.0")

# CORS untuk akses dari GitHub Pages, Codespaces, domain publik, dll.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # produksi: ganti ke domain frontend Anda
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def health():
    return {"message": "FTTH AutoDesigner Backend aktif"}

def _parse_boundary(boundary: Any) -> List[Tuple[float, float]]:
    """
    Kembalikan list tuple (lat, lng) dari berbagai kemungkinan format:
    - List of {lat, lng}
    - List of [lat, lng]
    - GeoJSON Feature/Geometry: coordinates[0] berupa [lng, lat]
    """
    # List of dicts: [{lat, lng}, ...]
    if isinstance(boundary, list) and boundary and isinstance(boundary[0], dict):
        return [(float(p["lat"]), float(p["lng"])) for p in boundary]

    # List of lists: [[lat, lng], ...]
    if isinstance(boundary, list) and boundary and isinstance(boundary[0], (list, tuple)):
        return [(float(p[0]), float(p[1])) for p in boundary]

    # GeoJSON Feature or Geometry
    if isinstance(boundary, dict):
        geom = boundary.get("geometry", boundary)
        if isinstance(geom, dict) and geom.get("type") == "Polygon":
            coords = geom.get("coordinates", [])
            if coords and isinstance(coords[0], list):
                ring = coords[0]  # outer ring
                # GeoJSON = [lng, lat]
                return [(float(lat), float(lng)) for (lng, lat) in ring]

    raise ValueError("Format boundary tidak didukung")

@app.post("/design/generate-odp")
async def generate_odp(req: Request):
    data = await req.json()
    boundary_raw = data.get("boundary")
    odc = data.get("odc_location") or data.get("odc_point")
    if not boundary_raw or not odc:
        return {"status": "error", "message": "boundary dan odc_location wajib diisi"}

    try:
        boundary: List[Tuple[float, float]] = _parse_boundary(boundary_raw)
    except Exception as e:
        return {"status": "error", "message": f"Boundary invalid: {e}"}

    # Dummy generator: buat 8 ODP tersebar dari titik ODC
    lat0, lng0 = float(odc["lat"]), float(odc["lng"])
    odp_points = []
    for i in range(8):
        dlat = (i % 4) * 0.0002
        dlng = (i // 4) * 0.00025
        odp_points.append({"lat": lat0 + dlat, "lng": lng0 + dlng})

    return {
        "status": "success",
        "message": "ODP generated",
        "odp_points": odp_points
    }

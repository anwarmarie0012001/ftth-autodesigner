import React, { useState } from "react"
import { MapContainer, TileLayer, Polygon, Marker, Popup, useMapEvents } from "react-leaflet"

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL ||
  (window.location.hostname.includes("github.dev")
    ? window.location.origin.replace(/-\d+\.app\.github\.dev$/, "-8000.app.github.dev")
    : "http://localhost:8000")

function Drawer({ onPolygonChange, onOdcChange }) {
  const [points, setPoints] = useState([])
  const [odc, setOdc] = useState(null)

  useMapEvents({
    click(e) {
      if (e.originalEvent.shiftKey) {
        setOdc(e.latlng)
        onOdcChange(e.latlng)
      } else {
        const next = [...points, e.latlng]
        setPoints(next)
        onPolygonChange(next)
      }
    },
    contextmenu() {
      setPoints([]); onPolygonChange([]); setOdc(null); onOdcChange(null)
    }
  })

  return <>
    {points.length > 0 && <Polygon positions={points} />}
    {odc && <Marker position={odc}><Popup>ODC</Popup></Marker>}
  </>
}

export default function App() {
  const [boundary, setBoundary] = useState([])
  const [odc, setOdc] = useState(null)
  const [odpPoints, setOdpPoints] = useState([])

  const send = async () => {
    if (!boundary.length || !odc) {
      alert("Klik peta untuk boundary (klik biasa), lalu SHIFT+klik untuk ODC.")
      return
    }
    const payload = {
      boundary: boundary.map(p => ({ lat: p.lat, lng: p.lng })),
      odc_location: { lat: odc.lat, lng: odc.lng }
    }
    try {
      const res = await fetch(`${BACKEND_URL}/design/generate-odp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      if (data.status === "success") setOdpPoints(data.odp_points)
      else alert(data.message || "Backend error")
    } catch (e) {
      console.error(e)
      alert(`Gagal menghubungi backend di ${BACKEND_URL}`)
    }
  }

  return (
    <div>
      <div className="header">FTTH AutoDesigner</div>
      <div className="toolbar">
        <button className="btn btn-primary" onClick={send}>Kirim Data ke Backend</button>
        <div className="hint">Klik biasa: tambah titik polygon. SHIFT+Klik: atur titik ODC. Klik kanan: reset.</div>
      </div>
      <MapContainer className="map" center={[-6.2, 106.816666]} zoom={14}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Drawer onPolygonChange={setBoundary} onOdcChange={setOdc} />
        {odpPoints.map((p, i) => (
          <Marker key={i} position={[p.lat, p.lng]}><Popup>ODP {i+1}</Popup></Marker>
        ))}
      </MapContainer>
    </div>
  )
}

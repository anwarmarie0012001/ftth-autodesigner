from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Union, Optional

router = APIRouter()

# ===== In-memory storage (demo/dev) =====
STATE = {
    "boundary": None,  # List[tuple(lng,lat)]
    "marker": None,    # tuple(lng,lat)
}

# ===== Schemas =====
class LatLng(BaseModel):
    lat: float
    lng: float

class BoundaryBody(BaseModel):
    # terima dua bentuk: [[lat,lng], ...] ATAU [{"lat":..,"lng":..}, ...]
    boundary: List[Union[List[float], LatLng]]

class MarkerBody(BaseModel):
    # terima [lat,lng] ATAU {"lat":..,"lng":..}
    marker: Union[List[float], LatLng, None] = None
    lat: Optional[float] = None
    lng: Optional[float] = None

# ===== Helpers =====
def _to_lnglat_list(items):
    """Normalize ke list[(lng,lat), ...]"""
    out = []
    for it in items:
        if isinstance(it, list) and len(it) >= 2:
            lat, lng = float(it[1]), float(it[0])
            out.append((lng, lat))
        elif isinstance(it, dict):
            lat, lng = float(it["lat"]), float(it["lng"])
            out.append((lng, lat))
        else:
            raise ValueError("Unsupported boundary point format")
    return out

def _to_lnglat_point(body: MarkerBody):
    if body.marker is not None:
        m = body.marker
        if isinstance(m, list) and len(m) >= 2:
            return (float(m[1]), float(m[0]))  # (lng,lat)
        if isinstance(m, dict):
            return (float(m["lng"]), float(m["lat"]))
    if body.lat is not None and body.lng is not None:
        return (float(body.lng), float(body.lat))
    raise ValueError("Unsupported marker format")

# ===== Endpoints =====
@router.post("/boundary")
def set_boundary(body: BoundaryBody):
    try:
        coords = _to_lnglat_list(body.boundary)
    except Exception as e:
        raise HTTPException(422, f"Bad boundary format: {e}")
    if len(coords) < 3:
        raise HTTPException(422, "Boundary needs at least 3 points")
    STATE["boundary"] = coords
    return {"ok": True, "points": [{"lat": y, "lng": x} for x, y in coords]}

@router.post("/marker")
def set_marker(body: MarkerBody):
    try:
        pt = _to_lnglat_point(body)
    except Exception as e:
        raise HTTPException(422, f"Bad marker format: {e}")
    STATE["marker"] = pt
    return {"ok": True, "position": {"lat": pt[1], "lng": pt[0]}}

@router.get("/current")
def get_current():
    b = STATE["boundary"]
    m = STATE["marker"]
    return {
        "boundary": [{"lat": y, "lng": x} for x, y in b] if b else None,
        "marker": {"lat": m[1], "lng": m[0]} if m else None,
    }

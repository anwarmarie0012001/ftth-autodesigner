from fastapi import APIRouter
from fastapi import Body
from shapely.geometry import shape, Point, mapping, MultiPoint
import requests
import math
import uuid
import numpy as np

router = APIRouter()


OVERPASS_URL = "https://overpass-api.de/api/interpreter"  # bisa juga http://overpass-api.de/api/interpreter


def fetch_osm_data_for_bbox(minlon, minlat, maxlon, maxlat):
    """
    Ambil data OSM (ways + nodes) di bbox via Overpass.
    Return parsed JSON.
    """
    query = f"""
    [out:json][timeout:25];
    (
      way["building"]({minlat},{minlon},{maxlat},{maxlon});
      way["highway"]({minlat},{minlon},{maxlat},{maxlon});
    );
    (._;>;);
    out body;
    """
    r = requests.post(OVERPASS_URL, data={"data": query}, timeout=60)
    r.raise_for_status()
    return r.json()


def parse_building_centroids(osm_json):
    """
    Dari Overpass JSON, kembalikan list titik centroid rumah (lon,lat) sebagai shapely Points.
    Consider ways with tag building (we accept any building tag).
    """
    elements = osm_json.get("elements", [])
    # map nodes
    nodes = {el["id"]: (el["lon"], el["lat"]) for el in elements if el["type"] == "node"}
    houses = []
    for el in elements:
        if el.get("type") == "way" and "tags" in el and "building" in el["tags"]:
            # take node coords sequence
            coords = [nodes.get(nid) for nid in el.get("nodes", []) if nodes.get(nid) is not None]
            if len(coords) >= 1:
                # if polygon like, compute centroid; else simple average.
                arr = np.array(coords)
                # average lon/lat is a reasonable centroid approximation for building footprint
                lon_mean, lat_mean = float(arr[:, 0].mean()), float(arr[:, 1].mean())
                houses.append(Point(lon_mean, lat_mean))
    return houses


def angular_groups_around_marker(houses, marker_point, min_size=8, max_size=16):
    """
    Group houses by angle around marker_point.
    - houses: list of shapely Points (lon, lat)
    - marker_point: shapely Point (lon, lat)
    Returns list of clusters; each cluster is dict {points:list of Points}
    """
    n = len(houses)
    if n < min_size:
        return []

    # compute number of clusters (try to keep each <= max_size)
    n_clusters = max(1, int(math.ceil(n / float(max_size))))
    # if n_clusters would make clusters smaller than min_size, reduce n_clusters
    while n_clusters > 1 and math.floor(n / n_clusters) < min_size:
        n_clusters -= 1

    # compute angle for each house relative to marker
    mx, my = marker_point.x, marker_point.y
    arr = []
    for p in houses:
        dx = p.x - mx
        dy = p.y - my
        angle = math.atan2(dy, dx)  # radians, -pi..pi
        arr.append((angle, p))

    arr.sort(key=lambda x: x[0])  # sort by angle

    # determine sizes per cluster (balanced)
    base = n // n_clusters
    extras = n % n_clusters
    sizes = [base + (1 if i < extras else 0) for i in range(n_clusters)]

    clusters = []
    idx = 0
    for size in sizes:
        group_pts = [arr[idx + j][1] for j in range(size)]
        idx += size
        clusters.append(group_pts)

    # result: list of clusters (each cluster is list of Points)
    return clusters


@router.post("/generate")
def generate_odp(payload: dict = Body(...)):
    """
    Payload expected:
    {
      "boundary": { GeoJSON geometry (Polygon) },   <- geometry object
      "marker": { GeoJSON Feature (Point) }         <- feature with geometry Point
    }

    Returns:
    {
      "clusters": [
         { "odp_id": str, "boundary": geojson_geom, "location": [lon, lat], "house_count": int },
         ...
      ]
    }
    """
    try:
        if "boundary" not in payload or "marker" not in payload:
            return {"status": "error", "message": "Payload must include 'boundary' and 'marker'."}

        boundary_geom = payload["boundary"]
        marker_feature = payload["marker"]

        # convert to shapely
        boundary_poly = shape(boundary_geom)
        marker_point = shape(marker_feature["geometry"])  # Point

        # bbox for Overpass (minx,miny,maxx,maxy)
        minx, miny, maxx, maxy = boundary_poly.bounds

        # fetch OSM data in bbox
        osm_json = fetch_osm_data_for_bbox(minx, miny, maxx, maxy)

        # parse building centroids
        houses = parse_building_centroids(osm_json)

        if not houses:
            return {"status": "error", "message": "No houses found in boundary area."}

        # filter houses strictly within boundary polygon (some building centroids may fall outside)
        houses_in = [h for h in houses if boundary_poly.contains(h)]
        if not houses_in:
            # fallback: use all houses but warn
            houses_in = houses

        # only proceed if at least min_size houses
        MIN = 8
        MAX = 16
        if len(houses_in) < MIN:
            return {"status": "error", "message": f"Not enough houses for ODP (found {len(houses_in)}, need at least {MIN})."}

        # cluster houses by angle around marker
        raw_clusters = angular_groups_around_marker(houses_in, marker_point, min_size=MIN, max_size=MAX)
        if not raw_clusters:
            return {"status": "error", "message": "Unable to form clusters with the given rules."}

        # build clusters output: convex hull per cluster & centroid location
        clusters_out = []
        for i, pts in enumerate(raw_clusters, start=1):
            # if a cluster is too small (<MIN) skip it
            if len(pts) < MIN:
                # try to merge with previous cluster if exists
                if clusters_out:
                    # merge into previous cluster: take union of polygons later (skip complex merge for simplicity)
                    # For now, append points to previous cluster by re-creating boundary later (not ideal but simple)
                    prev = clusters_out[-1]
                    # not re-creating cluster here; instead produce a single combined cluster at the end step
                    # For code simplicity, we skip merging complex cases (rare). We'll still produce hull for this small cluster if allowed.
                    pass

            multip = MultiPoint([(p.x, p.y) for p in pts])
            poly = multip.convex_hull
            centroid = poly.centroid
            clusters_out.append({
                "odp_id": f"ODP-{uuid.uuid4().hex[:6]}",
                "house_count": len(pts),
                "boundary": mapping(poly),    # GeoJSON geometry mapping
                "location": [round(float(centroid.x), 7), round(float(centroid.y), 7)]
            })

        return {"status": "success", "clusters": clusters_out}

    except requests.exceptions.RequestException as re:
        return {"status": "error", "message": "Overpass request failed: " + str(re)}
    except Exception as e:
        return {"status": "error", "message": str(e)}

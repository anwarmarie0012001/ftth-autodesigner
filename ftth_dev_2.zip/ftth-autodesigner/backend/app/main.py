from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Import routers
from routers import odp, odc

app = FastAPI(
    title="FTTH Autodesigner",
    description="Backend service untuk desain FTTH (ODC, ODP, dll) menggunakan OSM & Overpass API",
    version="1.0.0",
)

# Middleware CORS biar frontend React bisa akses
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # ganti dengan domain frontend kalau mau aman
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(odc.router, prefix="/odc", tags=["ODC"])
app.include_router(odp.router, prefix="/odp", tags=["ODP"])


@app.get("/")
def root():
    return {"message": "FTTH Autodesigner Backend is running"}


# Buat supaya bisa run langsung (python main.py)
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
